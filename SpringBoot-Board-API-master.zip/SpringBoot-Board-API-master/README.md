
### 구조

```
   ─myboard
       ├─domain
       │  ├─commnet
       │  │  ├─controller
       │  │  ├─dto
       │  │  ├─exception
       │  │  ├─repository
       │  │  └─service
       │  ├─member
       │  │  ├─controller
       │  │  ├─dto
       │  │  ├─exception
       │  │  ├─repository
       │  │  └─service
       │  └─post
       │      ├─cond
       │      ├─controller
       │      ├─dto
       │      ├─exception
       │      ├─repository
       │      └─service
       └─global
           ├─aop
           ├─cache
           ├─config
           ├─exception
           ├─file
           │  ├─exception
           │  └─service
           ├─jwt
           │  ├─filter
           │  └─service
           ├─log
           ├─login
           │  ├─filter
           │  └─handler
           └─util
               └─security

```

