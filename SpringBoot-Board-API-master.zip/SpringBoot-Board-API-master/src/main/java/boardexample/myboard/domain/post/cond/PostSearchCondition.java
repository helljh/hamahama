package boardexample.myboard.domain.post.cond;

import lombok.Data;

import java.util.Optional;

@Data
public class PostSearchCondition {

    private String title;
    private String content;


}
