package boardexample.myboard.domain.member;

public enum Role {
    USER, ADMIN
}
