package boardexample.myboard.global.cache;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class CacheLogin {

    public static final String USER = "login_user";

}
